# Remove audio/subtitle streams by language

plugin for [Unmanic](https://github.com/Unmanic)
